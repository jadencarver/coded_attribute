require 'coded_attribute'

class ActiveRecord::Base
  extend CodedAttribute
end
